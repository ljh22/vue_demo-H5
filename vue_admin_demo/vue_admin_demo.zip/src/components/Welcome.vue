<template>
    <div class="">
        <h3>Welcome</h3>
    </div>
</template>

<script>
    export default {
        data() {
            return {};
        },
    };
</script>

<style lang="less" scoped>
    h3 {
        background: linear-gradient(
            to right,
            #dc73c5,
            #cd74d1,
            #ba77dd,
            #a27be7,
            #847ff0,
            #658ffa,
            #419dfe,
            #00a9ff,
            #00c0ff,
            #00d6ff,
            #00e9fb,
            #5ffbf1
        );
        color: transparent;
        background-clip: text;
        font-size: 50px;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
    }
</style>
