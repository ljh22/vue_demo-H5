<template>
  <view class=''>
    mine
  </view>
</template>

<script>
  export default {
    name: '',
    // 数据参数
    data () {
      return {
      
      }
    },
    /*
      监听页面加载函数
    */
    onLoad() {},
    /*
      监听页面显示加载函数
    */
    onShow() {},
    /*
      事件处理函数
    */
    methods: {},
    /*
      监听页面初次渲染完成
    */
    onReady() {},
    /*
      监听监听页面隐藏
    */
    onHide() {},
    /*
      监听页面卸载
    */
    onUnload() {},
    /*
      监听窗口尺寸变化
    */
    onResize() {},
    /*
      监听用户下拉动作
    */
    onPullDownRefresh() {},
    /*
      页面滚动到底部的事件
    */
    onReachBottom() {},
    /*
      点击 tab 时触发
    */
    onTabItemTap() {},
    /*
      用户点击右上角分享
    */
    onShareAppMessage() {},
    /*
      监听页面滚动
    */
    onPageScroll() {},
    /*
      组件绑定
    */
    components: {},
    /*
      侦听器
    */
    watch:{},
    /*
      计算属性
    */
    computed: {}
  }
</script>

<style lang='scss' scoped>
  .tab-mine{}
</style>