module.exports = { 
	//request主域名， 已引入uview的vuex，页面中可直接使用
	baseUrl:"http://demo509.cdqqkj.com",
	
	//static静态图片存放目录, 已引入uview的vuex，页面中可直接使用，小程序图片超包大小时用
	staticUrl:"http://demo509.cdqqkj.com",
	
	//项目缓存前缀，避免本地多个项目冲突，uni.$func.cache()
	prefix:"",
	
	//腾讯地图秘钥
	map_key:"JGABZ-IBWR6-2S7SA-EM7F7-T6CBV-ZDFMJ", 
	
	//api对称加密key
	aes_key:"2020050100554789", //16位数字 
	
	//api对称加密iv
	aes_iv:"4lrwa3QxswqaGReY",
	 
}