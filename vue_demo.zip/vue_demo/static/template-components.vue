<template>
	<view class="plugin-name">
		
	</view>
</template>
<script>
export default {
	props:{
		
	},
	data() {
		return { 
			options:{}
		}
	}, 
	created(){
		
	},
	methods:{
		
	},
	watch:{},
	computed:{},
	destroyed(){}
}
</script>

<style lang="scss">
.plugin-name{ 
	
}
</style>
